package bean;

public class DoanhThu {
	private String nam;
	private String ngayThanhToan;
	private float tongDoanhThu;
	
	public DoanhThu() {
		// TODO Auto-generated constructor stub
	}
	
	public String getNam() {
		return nam;
	}

	public void setNam(String nam) {
		this.nam = nam;
	}

	public String getNgayThanhToan() {
		return ngayThanhToan;
	}

	public void setNgayThanhToan(String ngayThanhToan) {
		this.ngayThanhToan = ngayThanhToan;
	}

	public float getTongDoanhThu() {
		return tongDoanhThu;
	}

	public void setTongDoanhThu(float tongDoanhThu) {
		this.tongDoanhThu = tongDoanhThu;
	} 
}
